//Umar Akhtar
//L1F26BSCS0135

#include <iostream>
using namespace std;

int main()
{
	char letter;
	char symbol;

	cout << "Enter a letter: ";
	cin >> letter;

	cout << "Enter a symbol or digit: ";
	cin >> symbol;



	cout << "Letter: " << letter << endl;
	cout << "Symbol or digit: " << symbol;


		return 0;
}