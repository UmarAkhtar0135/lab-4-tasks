//Umar Akhtar
//L1F26BSCS0135


 
#include <iostream>
using namespace std;

int main()
{
    char gradeletter = 'A';
    char section = 'C';
    char initial = 'M';

    cout << "Grade: " << gradeletter << endl;
    cout << "Section: " << section << endl;
    cout << "Initial: " << initial << endl;

    // PRINT ASCII CODE
    cout << "ASCII code of the grade letter: "
        << (int)gradeletter << endl;

    cout << "Next grade letter: "
        << (char)(gradeletter + 1) << endl;

    cout << "Grade letter + 1 without cast: "
        << gradeletter + 1 << endl;

    cout << "Z - A: " << 'Z' - 'A' << endl;

    cout << "Grade after A, B, C: "
        << (char)(gradeletter + 3) << endl;

    return 0;
}
