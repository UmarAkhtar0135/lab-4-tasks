// Umar Akhtar
// L1F26BSCS0135

#include <iostream>
using namespace std;

int main()
{
    char first, second, third;

    // Part A: Using cin.get()


    cout << "Part A" << endl;
    cout << "Type three characters: ";
    cin.get(first);
    cin.get(second);
    cin.get(third);


    cout << "First : [" << first << "] code " << (int)first << endl;
    cout << "Second : [" << second << "] code " << (int)second << endl;
    cout << "Third : [" << third << "] code " << (int)third << endl;

    cin.ignore(1000, '\n');




    // Part B: Using cin >>


    cout << "\nPart B" << endl;
    cout << "Type three characters: ";
    cin >> first >> second >> third;



    cout << "First : [" << first << "] code " << (int)first << endl;
    cout << "Second : [" << second << "] code " << (int)second << endl;
    cout << "Third : [" << third << "] code " << (int)third << endl;

    return 0;
}