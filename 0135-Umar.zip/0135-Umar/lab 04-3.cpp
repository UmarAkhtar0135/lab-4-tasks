//Umar Akhtar
// L1F26BSCS0135

#include <iostream>
using namespace std;

int main()
{
	char Firstinitial;
	char secondinitial;
	char thirdinitial;


	cout << "Enter your first Initial: ";
	cin >> Firstinitial;

	cout << "Enter your second Initial: ";
	cin >> secondinitial;

	cout << "Enter your thrid Initial: ";
	cin >> thirdinitial;


	cout << "Badge: " << Firstinitial << "." << secondinitial << "." << thirdinitial << ".";

	// No, badge is the same because cin >> reads one character at a time and skips whitespace
	// No. cin >> treats the Enter key like whitespace.


	return 0;
}